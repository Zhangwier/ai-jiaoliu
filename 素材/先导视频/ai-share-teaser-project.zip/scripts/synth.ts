// Original score for the AI 交流分享 teaser, synthesized deterministically from src/engine/score.ts.
// Writes out/score.wav (48 kHz stereo, 16-bit) and data/audio.json (60 Hz envelopes for
// audio-reactive visuals). Every musical event below is placed with bar()/beat() from the
// same cue table the scenes use, so picture and sound cannot drift apart.
import { writeFileSync, mkdirSync } from 'node:fs';
import { bar, beat, BEAT, BAR, CUE, DURATION, STEP_BEATS } from '../src/engine/score';
import { mulberry32 } from '../src/engine/util';

const SR = 48000;
const N = Math.ceil(DURATION * SR);
const L = new Float32Array(N), R = new Float32Array(N);
const sendL = new Float32Array(N), sendR = new Float32Array(N); // reverb send
const rnd = mulberry32(42);

const mtof = (m: number) => 440 * Math.pow(2, (m - 69) / 12);
const NOTE: Record<string, number> = { C: 0, 'C#': 1, Db: 1, D: 2, 'D#': 3, Eb: 3, E: 4, F: 5, 'F#': 6, Gb: 6, G: 7, 'G#': 8, Ab: 8, A: 9, 'A#': 10, Bb: 10, B: 11 };
const n = (s: string) => {
  const m = s.match(/^([A-G][b#]?)(-?\d)$/)!;
  return NOTE[m[1]!]! + (parseInt(m[2]!) + 1) * 12;
};

function add(i: number, l: number, r: number, send = 0) {
  if (i < 0 || i >= N) return;
  L[i] += l; R[i] += r;
  if (send) { sendL[i] += l * send; sendR[i] += r * send; }
}
const panLR = (pan: number) => [Math.cos((pan + 1) * Math.PI / 4), Math.sin((pan + 1) * Math.PI / 4)] as const;

// ---------- instruments ----------
function kick(t: number, amp = 1) {
  const i0 = Math.round(t * SR), len = Math.round(0.45 * SR);
  let ph = 0;
  for (let k = 0; k < len; k++) {
    const tt = k / SR;
    const f = 44 + 90 * Math.exp(-tt * 28);
    ph += (2 * Math.PI * f) / SR;
    const e = Math.exp(-tt * 7.5) * Math.min(1, tt * 2000);
    let s = Math.sin(ph) * e * 0.9 + (k < 120 ? (rnd() * 2 - 1) * 0.25 * (1 - k / 120) : 0);
    s = Math.tanh(s * 1.6) * amp * 0.62;
    add(i0 + k, s, s, 0.05);
  }
}
function noiseHit(t: number, amp: number, dec: number, hp: number, lp: number, pan = 0, send = 0.15, tone = 0) {
  const i0 = Math.round(t * SR), len = Math.round(dec * 6 * SR);
  let lo = 0, hi = 0, prev = 0, ph = 0;
  const [pl, pr] = panLR(pan);
  const al = Math.exp((-2 * Math.PI * lp) / SR), ah = Math.exp((-2 * Math.PI * hp) / SR);
  for (let k = 0; k < len; k++) {
    const tt = k / SR;
    const x = rnd() * 2 - 1;
    lo = lo * al + x * (1 - al);
    hi = ah * (hi + lo - prev); prev = lo;
    ph += (2 * Math.PI * tone) / SR;
    const e = Math.exp(-tt / dec) * Math.min(1, tt * 3000);
    const s = (hi * 1.6 + (tone ? Math.sin(ph) * 0.5 * Math.exp(-tt * 30) : 0)) * e * amp;
    add(i0 + k, s * pl, s * pr, send);
  }
}
const clap = (t: number, a = 1) => { for (let j = 0; j < 3; j++) noiseHit(t + j * 0.009, 0.28 * a, j < 2 ? 0.012 : 0.09, 900, 5200, 0, 0.3, 0); noiseHit(t, 0.15 * a, 0.05, 150, 900, 0, 0.1, 185); };
const hat = (t: number, a = 1, pan = 0.2) => noiseHit(t, 0.07 * a, 0.022, 7000, 16000, pan, 0.05);
const tick = (t: number, a = 1) => { noiseHit(t, 0.22 * a, 0.006, 2500, 9000, -0.15, 0.25, 2600); };
const keyClick = (t: number, a = 1, pan = 0) => noiseHit(t, 0.1 * a, 0.004, 1800, 7000, pan, 0.12, 1400);

/** Karplus–Strong pluck: the "human" melodic timbre. */
function pluck(t: number, note: number, amp = 0.3, dur = 2.5, pan = 0, bright = 0.5, send = 0.35) {
  const f = mtof(note), i0 = Math.round(t * SR);
  const P = Math.max(2, Math.round(SR / f));
  const buf = new Float32Array(P);
  for (let k = 0; k < P; k++) buf[k] = rnd() * 2 - 1;
  // pre-filter excitation for warmth
  for (let pass = 0; pass < 2 - bright * 2; pass++) for (let k = 1; k < P; k++) buf[k] = (buf[k]! + buf[k - 1]!) / 2;
  const [pl, pr] = panLR(pan);
  const len = Math.round(dur * SR);
  const damp = 0.4985 + bright * 0.0013;
  let idx = 0;
  for (let k = 0; k < len; k++) {
    const a = buf[idx]!, b = buf[(idx + 1) % P]!;
    const s = (a + b) * damp;
    buf[idx] = s;
    idx = (idx + 1) % P;
    const fade = k > len - 2000 ? (len - k) / 2000 : 1;
    const out = a * amp * fade;
    add(i0 + k, out * pl, out * pr, send);
  }
}
/** FM bell: the "machine" timbre — used only when an AI connection is drawn. */
function bell(t: number, note: number, amp = 0.12, dur = 2, pan = 0) {
  const f = mtof(note), i0 = Math.round(t * SR), len = Math.round(dur * SR);
  const [pl, pr] = panLR(pan);
  for (let k = 0; k < len; k++) {
    const tt = k / SR;
    const mod = Math.sin(2 * Math.PI * f * 3.5 * tt) * 2.2 * Math.exp(-tt * 6);
    const s = Math.sin(2 * Math.PI * f * tt + mod) * Math.exp(-tt * 2.6) * Math.min(1, tt * 400) * amp;
    add(i0 + k, s * pl, s * pr, 0.5);
  }
}
/** Detuned-saw pad with one-pole low-pass and slow envelope. */
function pad(t: number, notes: number[], dur: number, amp = 0.05, cutoff = 1200, att = 0.6, rel = 1.2, send = 0.55) {
  const i0 = Math.round(t * SR), len = Math.round((dur + rel) * SR);
  const voices: { f: number; ph: number; pan: number }[] = [];
  notes.forEach((m, j) => [-0.09, 0, 0.11].forEach((d, v) => voices.push({ f: mtof(m + d), ph: rnd(), pan: ((v - 1) * 0.5 + (j % 2 ? 0.15 : -0.15)) })));
  let lpL = 0, lpR = 0;
  const a = Math.exp((-2 * Math.PI * cutoff) / SR);
  for (let k = 0; k < len; k++) {
    const tt = k / SR;
    let sl = 0, sr = 0;
    for (const v of voices) {
      v.ph += v.f / SR; v.ph -= Math.floor(v.ph);
      const s = v.ph * 2 - 1;
      const [pl, pr] = panLR(v.pan);
      sl += s * pl; sr += s * pr;
    }
    lpL = lpL * a + sl * (1 - a); lpR = lpR * a + sr * (1 - a);
    const env = Math.min(1, tt / att) * (tt > dur ? Math.exp(-(tt - dur) / (rel / 4)) : 1);
    const g = (amp * env) / voices.length * 3;
    add(i0 + k, lpL * g, lpR * g, send);
  }
}
function sub(t: number, note: number, dur: number, amp = 0.22) {
  const f = mtof(note), i0 = Math.round(t * SR), len = Math.round(dur * SR);
  let ph = 0;
  for (let k = 0; k < len; k++) {
    const tt = k / SR;
    ph += (2 * Math.PI * f) / SR;
    const env = Math.min(1, tt * 60) * Math.min(1, (dur - tt) * 30) * (0.75 + 0.25 * Math.exp(-tt * 4));
    const s = Math.tanh((Math.sin(ph) + 0.3 * Math.sin(2 * ph)) * 1.3) * amp * env;
    add(i0 + k, s, s, 0.02);
  }
}
function drone(t: number, notes: number[], dur: number, amp = 0.05) {
  const i0 = Math.round(t * SR), len = Math.round(dur * SR);
  for (let k = 0; k < len; k++) {
    const tt = k / SR;
    const env = Math.min(1, tt / 1.5) * Math.min(1, (dur - tt) / 1.5);
    let s = 0;
    notes.forEach((m, j) => { const f = mtof(m); s += Math.sin(2 * Math.PI * f * tt + j) * (1 + 0.2 * Math.sin(tt * 0.7 + j)); });
    s *= (amp * env) / notes.length;
    add(i0 + k, s, s, 0.4);
  }
}
/** Rising noise swipe (brush / riser). */
function swipe(t: number, dur: number, amp = 0.3, f0 = 300, f1 = 6000, pan0 = -0.6, pan1 = 0.6, send = 0.3) {
  const i0 = Math.round(t * SR), len = Math.round(dur * SR);
  let lo = 0, hi = 0, prev = 0;
  for (let k = 0; k < len; k++) {
    const u = k / len;
    const fc = f0 * Math.pow(f1 / f0, u);
    const al = Math.exp((-2 * Math.PI * fc * 1.6) / SR), ah = Math.exp((-2 * Math.PI * fc * 0.6) / SR);
    const x = rnd() * 2 - 1;
    lo = lo * al + x * (1 - al);
    hi = ah * (hi + lo - prev); prev = lo;
    const env = Math.pow(u, 1.5) * Math.min(1, (1 - u) * 40);
    const [pl, pr] = panLR(pan0 + (pan1 - pan0) * u);
    add(i0 + k, hi * env * amp * 2 * pl, hi * env * amp * 2 * pr, send);
  }
}
function boom(t: number, amp = 0.8, note = n('D1')) {
  const i0 = Math.round(t * SR), len = Math.round(3.5 * SR);
  let ph = 0;
  for (let k = 0; k < len; k++) {
    const tt = k / SR;
    const f = mtof(note) * (1 + 1.5 * Math.exp(-tt * 18));
    ph += (2 * Math.PI * f) / SR;
    const s = Math.tanh(Math.sin(ph) * 2) * Math.exp(-tt * 1.4) * Math.min(1, tt * 1500) * amp * 0.5;
    add(i0 + k, s, s, 0.25);
  }
  noiseHit(t, amp * 0.35, 0.25, 60, 2500, 0, 0.5);
}


// ---------- the score (A minor → C major at the title) ----------
const b = bar;
const chords: Record<string, string[]> = {
  Am: ['A2', 'C3', 'E3', 'A3'], F: ['F2', 'A2', 'C3', 'F3'], C: ['C3', 'E3', 'G3', 'C4'], G: ['G2', 'B2', 'D3', 'G3'],
  Dm: ['D3', 'F3', 'A3', 'D4'], Esus: ['E2', 'A2', 'B2', 'E3'], E: ['E2', 'G#2', 'B2', 'E3'], Fmaj7: ['F2', 'A2', 'C3', 'E3'],
  Cadd9: ['C3', 'G3', 'D4', 'E4'],
};
const roots: Record<string, string> = { Am: 'A1', F: 'F1', C: 'C2', G: 'G1', Dm: 'D2', Esus: 'E1', E: 'E1', Fmaj7: 'F1', Cadd9: 'C2' };
const arp = (ch: string, i: number, oct = 12) => { const c = chords[ch]!.map(n); return c[i % c.length]! + oct * Math.floor(i / c.length); };

// TOKEN (bars 0–4): a pulse of ticks, typing, and one bell per chosen token
swipe(0.0, 0.5, 0.25, 500, 9000, -0.6, 0.6, 0.2);
drone(b(0), [n('A1'), n('E2')], BAR * 4.1, 0.08);
for (let k = 0; k < 16; k++) tick(beat(k), k % 4 === 0 ? 0.9 : 0.45);
for (let k = 0; k < 14; k++) keyClick(b(0) + 0.1 + k * (1.2 / 14), 1, -0.3 + (k % 3) * 0.3);
const tokNotes = ['A5', 'E6', 'C6', 'F5', 'B5', 'A5', 'E6'];
STEP_BEATS.forEach((bt, j) => {
  bell(beat(bt) + 0.28, n(tokNotes[j]!), j === 3 ? 0.1 : 0.075, 1.8, -0.5 + j * 0.16);
  noiseHit(beat(bt), 0.05, 0.02, 3000, 12000, 0.3, 0.1); // candidates flicker in
  if (j === 3) { noiseHit(beat(bt) + 0.3, 0.12, 0.08, 400, 3000, 0, 0.3, 90); pluck(beat(bt) + 0.3, n('F3'), 0.12, 2.5, 0, 0.3); }
});
sub(b(1), n('A1'), BAR * 2, 0.08);
pad(b(2), chords.Am!.map((x) => n(x) + 12), BAR * 1.8, 0.03, 900, 1.2, 0.6);
swipe(b(3.0), BAR * 0.3, 0.22, 200, 9000, -0.2, 0.2, 0.35);
boom(b(3.3), 0.6, n('A1')); // 它在一个字一个字地猜
pluck(b(3.3), n('A3'), 0.2, 3, 0, 0.4); pluck(b(3.3), n('E4'), 0.12, 3, 0.2, 0.4);

// PROBLEMS (bars 4–10): beat arrives
const prog4 = ['Am', 'Am', 'F', 'C', 'G', 'Esus'];
prog4.forEach((ch, j) => {
  const t = b(4 + j);
  sub(t, n(roots[ch]!), BAR * 0.98, 0.18);
  pad(t, chords[ch]!.map((x) => n(x) + 12), BAR, 0.03 + j * 0.003, 1200 + j * 250, 0.2, 0.6);
  for (let q = 0; q < 4; q++) kick(t + q * BEAT, q === 0 ? 1 : 0.7);
  clap(t + BEAT, 0.7); clap(t + BEAT * 3, 0.7);
  for (let k = 0; k < 8; k++) hat(t + k * BEAT / 2 + BEAT / 4, k % 2 ? 0.5 : 0.85);
});
// 抽卡: branching arpeggio that spreads in pitch
for (let k = 0; k < 24; k++) pluck(b(4.5) + k * BEAT / 4, arp('Am', k, 12) + 12 + (k > 8 ? (k % 3) * 2 : 0), 0.06, 1.2, Math.sin(k * 1.7) * 0.7, 0.7, 0.35);
for (let k = 0; k < 12; k++) bell(b(5) + k * BEAT / 4, n(['A5', 'C6', 'E6', 'G6'][k % 4]!) + (k % 2) * 12, 0.025, 1, Math.sin(k) * 0.8);
// each problem's downbeat: a hit
[6, 7, 8, 9].forEach((bb) => { boom(b(bb), 0.45, n('A1')); noiseHit(b(bb), 0.12, 0.4, 2000, 12000, 0, 0.4); });
// 幻觉: glitch scramble at bar 6 + ~0.9
for (let k = 0; k < 10; k++) noiseHit(b(6) + 0.7 + k * 0.04, 0.09, 0.01, 1500 + k * 400, 9000, (k % 2 ? 0.5 : -0.5), 0.1, 300 + k * 90);
// 迎合: seven agreeable little ticks of "found one!"
for (let k = 0; k < 7; k++) pluck(b(7) + 0.75 + k * 0.12, n(['E5', 'G5', 'A5', 'C6', 'D6', 'E6', 'G6'][k]!), 0.07, 0.8, -0.4 + k * 0.13, 0.8);
// 上下文腐烂: a detuned smear
pad(b(8) + 0.9, [n('A4'), n('A#4'), n('E5')], 1.0, 0.03, 2500, 0.4, 0.5);
// recap words on half-beats
for (let k = 0; k < 4; k++) { kick(b(9) + k * BEAT * 0.5, 0.6); pluck(b(9) + k * BEAT * 0.5, n(['A4', 'C5', 'E5', 'A5'][k]!), 0.1, 1.5, -0.3 + k * 0.2, 0.6); }
swipe(b(9.5), BAR * 0.5, 0.25, 200, 10000, -0.4, 0.4, 0.3);

// PELICAN (bars 10–14): full groove, tiles pop on eighths
const prog10 = ['F', 'C', 'G', 'Am'];
prog10.forEach((ch, j) => {
  const t = b(10 + j);
  for (let q = 0; q < 4; q++) kick(t + q * BEAT, q === 0 ? 1 : 0.85);
  clap(t + BEAT, 1); clap(t + BEAT * 3, 1);
  for (let k = 0; k < 16; k++) hat(t + k * BEAT / 4, k % 4 === 2 ? 1 : 0.4, k % 2 ? 0.35 : -0.1);
  for (let k = 0; k < 8; k++) sub(t + k * BEAT / 2, n(roots[ch]!) + (k % 4 === 3 ? 12 : 0), BEAT / 2 * 0.9, 0.18);
  pad(t, chords[ch]!.map((x) => n(x) + 12), BAR, 0.035, 2400, 0.1, 0.6);
  if (j === 0) for (let k = 0; k < 14; k++) keyClick(b(10) + 0.1 + k * (1.5 / 14), 0.8, -0.3 + (k % 3) * 0.3);
});
for (let k = 0; k < 10; k++) pluck(b(11) + k * BEAT / 2, n(['A4', 'C5', 'E5', 'G5', 'A5', 'C6', 'E6', 'G6', 'A6', 'C7'][k]!), 0.1, 1.6, -0.7 + k * 0.15, 0.85, 0.4);
for (let k = 0; k < 10; k++) noiseHit(b(11) + k * BEAT / 2, 0.08, 0.02, 4000, 14000, -0.7 + k * 0.15, 0.2);
bell(b(12.5), n('E6'), 0.08, 2, 0.2);
boom(b(13), 0.5, n('A1'));

// CASES (bars 14–20): half-time, paper, ticks of checking
const prog14 = ['Dm', 'Dm', 'F', 'Am', 'Dm', 'Esus'];
prog14.forEach((ch, j) => {
  const t = b(14 + j);
  kick(t, 0.9); kick(t + BEAT * 2.5, 0.6);
  clap(t + BEAT * 2, 0.8);
  for (let k = 0; k < 8; k++) tick(t + k * BEAT / 2, k % 2 ? 0.25 : 0.45);
  sub(t, n(roots[ch]!), BAR * 0.95, 0.16);
  pad(t, chords[ch]!.map((x) => n(x) + 12), BAR, 0.035, 1100, 0.3, 0.7);
});
// pen marks: short scratches when the human circles / strikes
[15.125, 15.875, 16.1].forEach((bb, j) => noiseHit(b(bb), 0.08, 0.12, 2500, 6500, -0.2 + j * 0.2, 0.1));
// scoreboard counters roll
for (let k = 0; k < 20; k++) keyClick(b(16) + 0.4 + k * 0.05, 0.6, Math.sin(k) * 0.5);
boom(b(16), 0.5, n('D2'));
for (let k = 0; k < 9; k++) noiseHit(b(16) + 1.0 + k * 0.15, 0.06, 0.06, 2500, 6500, -0.5 + k * 0.12, 0.1);
// report numbers roll
boom(b(17), 0.5, n('D2'));
for (let k = 0; k < 30; k++) keyClick(b(17) + 0.3 + k * 0.04, 0.5, Math.cos(k) * 0.5);
noiseHit(b(18) + 0.35, 0.1, 0.1, 2500, 6500, 0, 0.1); // strike
noiseHit(b(18.75) + 0.35, 0.1, 0.1, 2500, 6500, 0.2, 0.1); // cross
pluck(b(18.75) + 0.95, n('E5'), 0.14, 2, 0.2, 0.7); pluck(b(18.75) + 1.05, n('A5'), 0.12, 2, 0.3, 0.7); // tick
// 交付物像样，仍要人来核
boom(b(19), 0.7, n('A1')); pluck(b(19), n('A3'), 0.18, 3, 0, 0.4); pluck(b(19), n('E4'), 0.12, 3, 0.2, 0.4);
swipe(b(19.5), BAR * 0.5, 0.25, 200, 10000, -0.3, 0.3, 0.3);

// TAKEAWAY (bars 20–25): three hits, then the lift
pad(b(20), chords.Fmaj7!.map((x) => n(x) + 12), BAR, 0.05, 1600, 0.3, 0.6);
sub(b(20), n('F1'), BAR, 0.14);
for (let k = 0; k < 8; k++) pluck(b(20) + k * BEAT / 2, arp('Fmaj7', k, 12) + 12, 0.06, 1.2, k % 2 ? 0.3 : -0.3, 0.6);
const prog21 = ['Am', 'F', 'G', 'C'];
prog21.forEach((ch, j) => {
  const t = b(21 + j);
  boom(t, j === 3 ? 0.8 : 0.65, n(roots[ch]!) - (j === 3 ? 12 : 0));
  noiseHit(t, 0.18, 0.5, 2000, 15000, 0, 0.5);
  for (let q = 0; q < 4; q++) kick(t + q * BEAT, q === 0 ? 1 : 0.75);
  clap(t + BEAT, 0.9); clap(t + BEAT * 3, 0.9);
  for (let k = 0; k < 16; k++) hat(t + k * BEAT / 4, k % 4 === 2 ? 0.9 : 0.35, k % 2 ? 0.3 : -0.2);
  for (let k = 0; k < 8; k++) sub(t + k * BEAT / 2, n(roots[ch]!) + (k % 4 === 3 ? 12 : 0), BEAT / 2 * 0.9, 0.18);
  pad(t, chords[ch]!.map((x) => n(x) + 12), BAR, 0.04, 2600, 0.05, 0.6);
  for (let k = 0; k < 16; k++) pluck(t + k * BEAT / 4, arp(ch, (k * 5) % 9, 12) + 12, 0.045, 0.8, Math.sin(k) * 0.6, 0.75, 0.3);
});
pluck(b(23) + 0.9, n('E6'), 0.12, 2, 0.4, 0.8); // the coral tick
swipe(b(24.5), BAR * 0.5, 0.3, 150, 12000, -0.5, 0.5, 0.35);

// TITLE (bars 25–31): questions on half bars, then C major for the title
['Dm', 'Esus'].forEach((ch, j) => { pad(b(25 + j), chords[ch]!.map((x) => n(x) + 12), BAR, 0.05, 1500, 0.2, 0.6); sub(b(25 + j), n(roots[ch]!), BAR, 0.16); });
[25, 25.5, 26].forEach((bb, j) => { kick(b(bb), 0.8); pluck(b(bb), n(['A4', 'C5', 'E5'][j]!), 0.15, 2.5, -0.3 + j * 0.3, 0.6); });
for (let k = 0; k < 8; k++) tick(b(26) + k * BEAT / 2, 0.3 + k * 0.08);
swipe(b(26.25), BAR * 0.75, 0.3, 150, 12000, -0.5, 0.5, 0.35);
// the title tokens: three bells on beats
['C6', 'E6', 'G6'].forEach((m, k) => { bell(b(27) + k * BEAT, n(m), 0.1, 3, -0.4 + k * 0.4); });
boom(b(27), 1.0, n('C1')); kick(b(27), 1);
noiseHit(b(27), 0.22, 1.2, 2000, 15000, 0, 0.7);
pad(b(27), [...chords.Cadd9!.map((x) => n(x) + 12), n('C2')], BAR * 2, 0.08, 3200, 0.02, 3, 0.6);
sub(b(27), n('C1'), BAR * 1.6, 0.22);
pad(b(29), chords.Fmaj7!.map((x) => n(x) + 12), BAR, 0.05, 1800, 0.8, 1.5);
pad(b(30), chords.Cadd9!.map((x) => n(x) + 12), BAR * 1.2, 0.045, 1400, 0.8, 4);
sub(b(29), n('F1'), BAR, 0.12); sub(b(30), n('C2'), BAR, 0.1);
['C5', 'E5', 'G5', 'C6', 'D6', 'E6', 'G6', 'C7'].forEach((m, j) => pluck(b(28) + j * BEAT / 4, n(m), 0.08, 3, -0.7 + j * 0.2, 0.85, 0.6));
pluck(b(30), n('G4'), 0.1, 4, -0.2, 0.5); pluck(b(30) + BEAT * 2, n('E5'), 0.08, 4, 0.2, 0.5);
for (let k = 0; k < 4; k++) tick(b(30) + k * BEAT * 2, 0.25); // the cursor, still blinking

// ---------- reverb (4-line FDN) ----------
{
  const dl = [1557, 1617, 1491, 1422, 1277, 1356, 1188, 1116].map((x) => Math.round(x * 2.3));
  const bufs = dl.map((d) => new Float32Array(d));
  const idx = dl.map(() => 0);
  const lp = dl.map(() => 0);
  const fb = 0.86;
  for (let i = 0; i < N; i++) {
    const outs = bufs.map((bf, k) => bf[idx[k]!]!);
    let yl = 0, yr = 0;
    outs.forEach((o, k) => { if (k % 2) yr += o; else yl += o; });
    // Householder mix
    const sum = outs.reduce((a, b) => a + b, 0) * (2 / outs.length);
    outs.forEach((o, k) => {
      let v = (o - sum) * fb + (k % 2 ? sendR[i]! : sendL[i]!) * 0.35;
      lp[k] = lp[k]! * 0.45 + v * 0.55; // damping
      bufs[k]![idx[k]!] = lp[k]!;
      idx[k] = (idx[k]! + 1) % dl[k]!;
    });
    L[i] += yl * 0.32; R[i] += yr * 0.32;
  }
}

// ---------- master: gentle glue + limiter, fade tail ----------
let peak = 0;
for (let i = 0; i < N; i++) peak = Math.max(peak, Math.abs(L[i]!), Math.abs(R[i]!));
const pre = 0.95 / Math.max(0.3, Math.min(peak, 2.2));
const pcm = Buffer.alloc(N * 4);
for (let i = 0; i < N; i++) {
  const t = i / SR;
  const fade = t > DURATION - 2.5 ? Math.max(0, (DURATION - t) / 2.5) : 1;
  const l = Math.tanh(L[i]! * pre * 1.15) * 0.93 * fade, r = Math.tanh(R[i]! * pre * 1.15) * 0.93 * fade;
  L[i] = l; R[i] = r;
  pcm.writeInt16LE(Math.round(l * 32767), i * 4);
  pcm.writeInt16LE(Math.round(r * 32767), i * 4 + 2);
}
const hdr = Buffer.alloc(44);
hdr.write('RIFF', 0); hdr.writeUInt32LE(36 + pcm.length, 4); hdr.write('WAVE', 8); hdr.write('fmt ', 12);
hdr.writeUInt32LE(16, 16); hdr.writeUInt16LE(1, 20); hdr.writeUInt16LE(2, 22); hdr.writeUInt32LE(SR, 24);
hdr.writeUInt32LE(SR * 4, 28); hdr.writeUInt16LE(4, 32); hdr.writeUInt16LE(16, 34); hdr.write('data', 36); hdr.writeUInt32LE(pcm.length, 40);
mkdirSync('out', { recursive: true }); mkdirSync('data', { recursive: true });
writeFileSync('out/score.wav', Buffer.concat([hdr, pcm]));

// ---------- 60 Hz envelopes for the visuals ----------
const rate = 60, hop = SR / rate;
const rms: number[] = [], low: number[] = [], high: number[] = [];
let lo = 0, hp = 0, prevx = 0;
const al = Math.exp((-2 * Math.PI * 150) / SR), ah = Math.exp((-2 * Math.PI * 4000) / SR);
for (let f = 0; f < Math.floor(N / hop); f++) {
  let s = 0, sl = 0, sh = 0;
  for (let k = 0; k < hop; k++) {
    const i = Math.floor(f * hop + k);
    const x = (L[i]! + R[i]!) / 2;
    lo = lo * al + x * (1 - al);
    hp = ah * (hp + x - prevx); prevx = x;
    s += x * x; sl += lo * lo; sh += hp * hp;
  }
  rms.push(Math.sqrt(s / hop)); low.push(Math.sqrt(sl / hop)); high.push(Math.sqrt(sh / hop));
}
const norm = (a: number[]) => { const m = Math.max(...a) || 1; return a.map((v) => +(Math.min(1, v / m)).toFixed(4)); };
writeFileSync('data/audio.json', JSON.stringify({ rate, rms: norm(rms), low: norm(low), high: norm(high) }));
console.log('score.wav written', (N / SR).toFixed(1), 's, peak', peak.toFixed(2));
