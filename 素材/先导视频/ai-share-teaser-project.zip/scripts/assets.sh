#!/bin/sh
# Extract the deck's assets. $1 = unzipped pptx ppt/media directory.
set -e; M=$1; cd "$(dirname "$0")/.."; mkdir -p assets/pelican
cp $M/image2.png assets/sheet.png; cp $M/image20.png assets/k1.png; cp $M/image21.png assets/k2.png; cp $M/image3.png assets/report.png
L=ABCDEFGHIJ; i=1
for c in A B C D E F G H I J; do mkdir -p assets/pelican/$c; ffmpeg -v error -y -ss 1 -t 4 -i $M/media$i.mp4 -vf "fps=16,scale=360:270" -q:v 4 assets/pelican/$c/%02d.jpg; i=$((i+1)); done
