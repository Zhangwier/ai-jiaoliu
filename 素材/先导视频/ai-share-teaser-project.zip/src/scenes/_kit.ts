// Shared drawing kit for the teaser: grounds, captions, the human pen (coral), counters.
import type { C } from '../engine/env';
import { env } from '../engine/env';
import { P, rgba } from '../engine/palette';
import { W, H, clear } from '../engine/core';
import { text, glyphs, layout, type Fam } from '../engine/type';
import { clamp, ease, prog, hash, noise1, TAU, lerp } from '../engine/util';
import { bar, BEAT } from '../engine/score';

export { W, H };

/** Navy ground with a faint engineering grid that breathes with the low band. */
export function inkGround(c: C, t: number, low = 0, gridA = 0.05) {
  clear(c, P.ink);
  const g = c.createRadialGradient(W * 0.5, H * 0.45, 50, W * 0.5, H * 0.5, W * 0.75);
  g.addColorStop(0, rgba(P.ink2, 1));
  g.addColorStop(1, rgba(P.ink, 1));
  c.fillStyle = g;
  c.fillRect(0, 0, W, H);
  if (gridA > 0) {
    c.save();
    c.strokeStyle = rgba(P.ash, gridA * (1 + low * 0.6));
    c.lineWidth = 1;
    c.beginPath();
    for (let x = 0; x <= W; x += 60) { c.moveTo(x + 0.5, 0); c.lineTo(x + 0.5, H); }
    for (let y = 0; y <= H; y += 60) { c.moveTo(0, y + 0.5); c.lineTo(W, y + 0.5); }
    c.stroke();
    c.restore();
  }
}

export function paperGround(c: C) {
  clear(c, P.paper);
}

/** Section tag, top-left: "01  认识 AI" in the deck's own manner. */
export function tag(c: C, num: string, label: string, a: number, dark = true) {
  if (a <= 0) return;
  const col = dark ? P.ash : P.graphite;
  text(c, num, 96, 92, { fam: 'Mono-Med', size: 22, color: dark ? P.machineOnInk : P.machineOnPaper, alpha: a });
  text(c, label, 140, 92, { fam: 'Sans-Regular', size: 22, color: col, alpha: a, track: 2 });
  c.save();
  c.globalAlpha = a * 0.6;
  c.fillStyle = col;
  c.fillRect(96, 108, 220 * a, 1.5);
  c.restore();
}

/**
 * Serif caption that writes in glyph by glyph (rise + unblur feel), holds, then leaves.
 * t0: start, t1: leave start.
 */
export function caption(c: C, s: string, x: number, y: number, t: number, t0: number, t1: number, o: { size?: number; color?: string; align?: 'left' | 'center' | 'right'; fam?: Fam; stagger?: number; track?: number } = {}) {
  const st = o.stagger ?? 0.035;
  return glyphs(c, s, x, y, { fam: o.fam ?? 'Serif-Bold', size: o.size ?? 72, color: o.color ?? P.paper, align: o.align ?? 'center', track: o.track ?? 4 }, (i, n) => {
    const a = prog(t, t0 + i * st, t0 + i * st + 0.35, ease.outCubic);
    const out = prog(t, t1 + i * 0.012, t1 + i * 0.012 + 0.25, ease.inCubic);
    return { a: a * (1 - out), dy: (1 - a) * 26 - out * 18 };
  });
}

/** Typewriter: returns the visible string at time t (cps chars per second). */
export function typed(s: string, t: number, t0: number, dur: number) {
  const ch = Array.from(s);
  const k = Math.floor(clamp((t - t0) / dur) * ch.length + 1e-6);
  return ch.slice(0, k).join('');
}

/** Blinking block cursor (deterministic). */
export function cursor(c: C, x: number, y: number, h: number, t: number, color: string, a = 1) {
  const on = Math.floor(t / 0.5) % 2 === 0 ? 1 : 0.15;
  c.save();
  c.globalAlpha = a * on;
  c.fillStyle = color;
  c.fillRect(x, y - h * 0.8, h * 0.46, h * 0.95);
  c.restore();
}

/** The human pen: a hand-drawn coral ellipse written over [t0, t0+dur]. */
export function penCircle(c: C, cx: number, cy: number, rx: number, ry: number, t: number, t0: number, dur = 0.45, seed = 1, color = P.human, lw = 5) {
  const p = prog(t, t0, t0 + dur, ease.inOutCubic);
  if (p <= 0) return;
  c.save();
  c.strokeStyle = color;
  c.lineCap = 'round';
  c.lineJoin = 'round';
  const N = 90, a0 = -2.2 + hash(seed) * 0.6, turns = 1.12;
  c.beginPath();
  for (let i = 0; i <= N * p; i++) {
    const u = i / N;
    const a = a0 + u * TAU * turns;
    const wob = 1 + noise1(u * 6, seed) * 0.05 + u * 0.06;
    const x = cx + Math.cos(a) * rx * wob, y = cy + Math.sin(a) * ry * wob;
    if (i === 0) c.moveTo(x, y); else c.lineTo(x, y);
  }
  c.lineWidth = lw;
  c.stroke();
  c.restore();
}

/** Pen strike-through across [x0,x1] at y. */
export function penStrike(c: C, x0: number, x1: number, y: number, t: number, t0: number, dur = 0.25, color = P.human, lw = 5) {
  const p = prog(t, t0, t0 + dur, ease.outCubic);
  if (p <= 0) return;
  c.save();
  c.strokeStyle = color;
  c.lineWidth = lw;
  c.lineCap = 'round';
  c.beginPath();
  c.moveTo(x0, y + 4);
  c.lineTo(lerp(x0, x1, p), y - 4 * p);
  c.stroke();
  c.restore();
}

/** Pen tick (✓) written over dur. */
export function penTick(c: C, x: number, y: number, s: number, t: number, t0: number, dur = 0.35, color = P.human, lw = 8) {
  const p = prog(t, t0, t0 + dur, ease.inOutCubic);
  if (p <= 0) return;
  const pts = [[-0.5, 0], [-0.12, 0.42], [0.62, -0.55]];
  const seg1 = Math.hypot(0.38, 0.42), seg2 = Math.hypot(0.74, 0.97), Ltot = seg1 + seg2;
  let d = p * Ltot;
  c.save();
  c.strokeStyle = color; c.lineWidth = lw; c.lineCap = 'round'; c.lineJoin = 'round';
  c.beginPath();
  c.moveTo(x + pts[0]![0]! * s, y + pts[0]![1]! * s);
  for (let k = 1; k < 3; k++) {
    const [ax, ay] = pts[k - 1]!, [bx, by] = pts[k]!;
    const L = Math.hypot(bx! - ax!, by! - ay!);
    const u = clamp(d / L);
    c.lineTo(x + lerp(ax!, bx!, u) * s, y + lerp(ay!, by!, u) * s);
    d -= L;
    if (d <= 0) break;
  }
  c.stroke();
  c.restore();
}

/** Pen cross (✕). */
export function penCross(c: C, x: number, y: number, s: number, t: number, t0: number, color = P.human, lw = 7) {
  const p1 = prog(t, t0, t0 + 0.15, ease.outCubic), p2 = prog(t, t0 + 0.15, t0 + 0.3, ease.outCubic);
  c.save();
  c.strokeStyle = color; c.lineWidth = lw; c.lineCap = 'round';
  if (p1 > 0) { c.beginPath(); c.moveTo(x - s, y - s); c.lineTo(x - s + 2 * s * p1, y - s + 2 * s * p1); c.stroke(); }
  if (p2 > 0) { c.beginPath(); c.moveTo(x + s, y - s); c.lineTo(x + s - 2 * s * p2, y - s + 2 * s * p2); c.stroke(); }
  c.restore();
}

/** Rolling-digit number: each digit settles left→right (unsettled digits flicker deterministically). */
export function rollNumber(c: C, s: string, x: number, y: number, t: number, t0: number, dur: number, o: { size: number; color: string; fam?: Fam; align?: 'left' | 'center' | 'right'; track?: number }) {
  return glyphs(c, s, x, y, { fam: o.fam ?? 'Mono-Med', size: o.size, color: o.color, align: o.align ?? 'left', track: o.track ?? 0 }, (i, n, ch) => {
    if (t < t0) return { a: 0 };
    const settle = t0 + (dur * (i + 1)) / n;
    if (/[0-9]/.test(ch) && t < settle) return { a: 0.8, ch: String(Math.floor(hash(Math.floor(t * 30), i) * 10)) };
    return { a: 1, dy: -6 * Math.max(0, 1 - (t - settle) / 0.12) };
  });
}

/** Bitmap helper with optional cover-fit. */
export function img(c: C, key: string, x: number, y: number, w: number, h: number, a = 1) {
  const im = env.images[key];
  if (!im || a <= 0) return;
  c.save();
  c.globalAlpha *= a;
  c.drawImage(im, x, y, w, h);
  c.restore();
}

export { bar, BEAT, P, rgba, text, glyphs, layout, clamp, ease, prog, hash, noise1, TAU, lerp };
