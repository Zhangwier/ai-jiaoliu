// 03 · 两个真实案例: the drawing review (K1 / K2, 3 of 10, 30 false errors) and the
// revision report (totals that recompute, a typo, a template left unchanged). Paper ground:
// these are documents. Coral appears only where a person checks.
import type { Scene, Frame } from '../engine/scene';
import type { C } from '../engine/env';
import { S, at, bar, BEAT } from '../engine/score';
import { paperGround, tag, caption, text, img, rollNumber, penCircle, penStrike, penCross, penTick, P, rgba, prog, ease, clamp, lerp, hash, W, H } from './_kit';
import { env } from '../engine/env';

const FALSE = ['陈d喜', 'β()', '3-9', '1349', '缺少 β(°) 列', '仅有左侧挡块', 'α+γ 不闭合', '共重偏大 0.1kg', 'mm/cm 混用'];

export default class Cases implements Scene {
  id = 'cases';
  start = bar(S.cases[0]);
  end = bar(S.cases[1]);

  render(c: C, f: Frame) {
    const t = f.t;
    paperGround(c);
    const B = bar;
    tag(c, '03', '两个真实案例', prog(t, this.start, this.start + 0.4) * (1 - prog(t, this.end - 0.3, this.end)), false);

    if (t < at('rIntro')) this.drawing(c, t);
    else this.report(c, t);
    return { ground: 'paper' as const, grain: 0.06 };
  }

  drawing(c: C, t: number) {
    const B = bar, i0 = at('dIntro');
    const out = prog(t, at('rIntro') - 0.15, at('rIntro'));
    const A = 1 - out;
    text(c, '案例一', 96, 190, { fam: 'Sans-Black', size: 64, color: P.ink, alpha: A * prog(t, i0, i0 + 0.25) });
    text(c, '同一张挡块图纸，交给十个配置审查', 330, 188, { fam: 'Sans-Regular', size: 36, color: P.graphite, alpha: A * prog(t, i0 + 0.15, i0 + 0.4) });

    // the full sheet, pushing in slowly
    const sa = prog(t, i0 + 0.1, i0 + 0.5) * (1 - prog(t, at('dK1') - 0.1, at('dK1') + 0.15));
    if (sa > 0) {
      const z = lerp(1, 1.12, prog(t, i0, at('dK1'), ease.inOutQuad));
      const w = 1450 * 1.05 * z, h = 720 * 1.05 * z;
      img(c, 'sheet', (W - w) / 2, 250 + (760 - h) / 2 + 20, w, h, sa * A);
      // scan line
      const sx = lerp(200, 1720, prog(t, i0 + 0.4, at('dK1') - 0.1, ease.inOutCubic));
      c.save(); c.globalAlpha = sa * A * 0.8; c.fillStyle = P.machineOnPaper; c.fillRect(sx, 260, 3, 760);
      c.globalAlpha = sa * A * 0.12; c.fillRect(sx - 80, 260, 80, 760); c.restore();
    }

    // K1 & K2 side by side, with the human pen
    const ka = prog(t, at('dK1'), at('dK1') + 0.2) * (1 - prog(t, at('dScore') - 0.1, at('dScore') + 0.1));
    if (ka > 0) {
      img(c, 'k1', 110, 232, 1040 * 0.9, 810 * 0.9, ka * A);
      // circle the printed total-length formula (K1)
      penCircle(c, 500, 894, 380, 46, t, at('dK1') + 0.25, 0.4, 3);
      const l1 = ka * A * prog(t, at('dK1') + 0.55, at('dK1') + 0.7);
      text(c, 'K1', 120, 1000, { fam: 'Mono-Med', size: 34, color: P.human, alpha: l1 });
      text(c, '各段加起来比总长公式多 45 cm', 180, 1000, { fam: 'Sans-Bold', size: 34, color: P.human, alpha: l1 });
      const k2a = prog(t, at('dK2'), at('dK2') + 0.2) * ka;
      img(c, 'k2', 1260, 232, 482, 680, k2a * A);
      penCircle(c, 1292, 462, 34, 62, t, at('dK2') + 0.15, 0.3, 5);
      penCircle(c, 1597, 490, 52, 34, t, at('dK2') + 0.4, 0.3, 8);
      const l2 = k2a * A * prog(t, at('dK2') + 0.6, at('dK2') + 0.75);
      text(c, 'K2', 1260, 1000, { fam: 'Mono-Med', size: 34, color: P.human, alpha: l2 });
      text(c, '图上 sinα，公式 sinβ', 1320, 1000, { fam: 'Sans-Bold', size: 34, color: P.human, alpha: l2 });
    }

    // the scoreboard: 3 / 10 and 30 false errors
    const s0 = at('dScore');
    if (t > s0 - 0.1) {
      const a = prog(t, s0, s0 + 0.2) * A;
      // ten dots, three filled
      for (let i = 0; i < 10; i++) {
        const hit = i < 3;
        const d = prog(t, s0 + i * 0.05, s0 + i * 0.05 + 0.15, ease.outBack);
        c.save(); c.globalAlpha = a * d;
        c.beginPath(); c.arc(170 + i * 64, 420, 22, 0, Math.PI * 2);
        if (hit) { c.fillStyle = P.machineOnPaper; c.fill(); } else { c.strokeStyle = P.ash; c.lineWidth = 3; c.stroke(); }
        c.restore();
      }
      text(c, '3', 150, 650, { fam: 'Mono-Med', size: 220, color: P.machineOnPaper, alpha: a });
      text(c, '/ 10', 300, 650, { fam: 'Mono', size: 90, color: P.graphite, alpha: a });
      text(c, '个配置找到了关键问题', 150, 730, { fam: 'Sans-Regular', size: 36, color: P.graphite, alpha: a });
      // false errors counter + flying snippets
      const n = Math.round(30 * prog(t, s0 + 0.4, s0 + 1.4, ease.outCubic));
      const ea = prog(t, s0 + 0.3, s0 + 0.5) * A;
      text(c, String(n), 1100, 650, { fam: 'Mono-Med', size: 220, color: P.warn, alpha: ea, align: 'right' });
      text(c, '条假错误', 1130, 650, { fam: 'Sans-Bold', size: 64, color: P.warn, alpha: ea });
      text(c, '说得很具体，但和原图对不上', 1130, 730, { fam: 'Sans-Regular', size: 34, color: P.graphite, alpha: ea });
      FALSE.forEach((s, i) => {
        const ti = s0 + 0.45 + i * 0.12;
        const p = prog(t, ti, ti + 0.3, ease.outCubic);
        if (p <= 0) return;
        const x = 1000 + hash(i, 1) * 700, y = 300 + hash(i, 2) * 140 + i * 6;
        text(c, s, x, y - (1 - p) * 20, { fam: 'Mono', size: 28, color: P.warn, alpha: A * p * 0.9 });
        penStrike(c, x - 6, x + 26 * Array.from(s).length * 0.8 + 10, y - 9, t, ti + 0.55 + i * 0.03, 0.15, P.human, 3);
      });
      caption(c, '只靠 OCR、看不见图的配置：零命中', W / 2, 920, t, s0 + 1.3, at('rIntro') - 0.3, { size: 46, color: P.ink, fam: 'Serif-Bold', stagger: 0.02 });
    }
  }

  report(c: C, t: number) {
    const i0 = at('rIntro');
    const A = 1 - prog(t, this.end - 0.15, this.end);
    text(c, '案例二', 96, 190, { fam: 'Sans-Black', size: 64, color: P.ink, alpha: A * prog(t, i0, i0 + 0.25) });
    text(c, '四个配置，按清单写修编报告', 330, 188, { fam: 'Sans-Regular', size: 36, color: P.graphite, alpha: A * prog(t, i0 + 0.15, i0 + 0.4) });

    // three numbers roll in (万元) — the recomputable baseline
    const nums: [string, string, string][] = [['41,638.9336', '修编前（万元）', P.ink], ['41,465.1967', '修编后（万元）', P.ink], ['−173.7369', '核减（万元）', P.machineOnPaper]];
    const up = prog(t, at('rTypo') - 0.2, at('rTypo') + 0.15, ease.inOutCubic);
    nums.forEach(([v, l, col], i) => {
      const x = 130 + i * 600, y = lerp(520, 330, up);
      const sz = lerp(84, 60, up);
      rollNumber(c, v, x, y, t, i0 + 0.3 + i * 0.25, 0.6, { size: sz, color: col });
      text(c, l, x, y + 50, { fam: 'Sans-Regular', size: 28, color: P.graphite, alpha: A * prog(t, i0 + 0.5 + i * 0.25, i0 + 0.8 + i * 0.25) });
    });
    text(c, '金额能独立复算，才能判断哪份写对了', 150, lerp(680, 2000, up), { fam: 'Sans-Regular', size: 32, color: P.graphite, alpha: A * prog(t, i0 + 1.2, i0 + 1.4) });

    // the typo: 41638.89 vs 41,638.9336
    const ty = at('rTypo');
    if (t > ty) {
      const a = prog(t, ty, ty + 0.2) * A;
      text(c, '某份报告写成', 150, 520, { fam: 'Sans-Regular', size: 30, color: P.graphite, alpha: a });
      text(c, '41638.89', 150, 610, { fam: 'Mono-Med', size: 76, color: P.warn, alpha: a });
      penStrike(c, 140, 560, 585, t, ty + 0.35, 0.2);
      text(c, '总额笔误', 590, 600, { fam: 'Sans-Bold', size: 36, color: P.human, alpha: prog(t, ty + 0.5, ty + 0.65) * A });
    }
    const tp = at('rTpl');
    if (t > tp) {
      const a = prog(t, tp, tp + 0.2) * A;
      text(c, '承建单位', 1000, 520, { fam: 'Sans-Regular', size: 30, color: P.graphite, alpha: a });
      text(c, '中铁十二局集团有限公司', 1000, 600, { fam: 'Sans-Bold', size: 52, color: P.warn, alpha: a });
      penCross(c, 1650, 584, 22, t, tp + 0.35);
      text(c, '照抄旧标段模板', 1000, 660, { fam: 'Sans-Regular', size: 30, color: P.human, alpha: prog(t, tp + 0.5, tp + 0.65) * A });
      const ok = prog(t, tp + 0.8, tp + 1.0) * A;
      text(c, '广州公路工程集团有限公司', 1000, 740, { fam: 'Sans-Bold', size: 52, color: P.machineOnPaper, alpha: ok });
      penTick(c, 1680, 722, 44, t, tp + 0.95);
      text(c, '与中标公告一致', 1000, 795, { fam: 'Sans-Regular', size: 28, color: P.graphite, alpha: ok });
    }
    const l0 = at('rLine');
    if (t > l0) {
      c.save(); c.globalAlpha = prog(t, l0, l0 + 0.3) * 0.92 * A; c.fillStyle = P.ink; c.fillRect(0, 880, W, 200); c.restore();
      caption(c, '交付物像样，仍要人来核', W / 2, 1000, t, l0 + 0.1, this.end + 1, { size: 72, color: P.paper, stagger: 0.04 });
    }
  }
}
