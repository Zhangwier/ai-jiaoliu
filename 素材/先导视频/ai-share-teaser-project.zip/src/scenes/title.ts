// Title: the deck's own three questions, then the title generated token by token —
// the film ends the way it began, with a cursor.
import type { Scene, Frame } from '../engine/scene';
import type { C } from '../engine/env';
import { S, at, bar, BEAT, DURATION } from '../engine/score';
import { inkGround, caption, text, glyphs, cursor, layout, P, rgba, prog, ease, clamp, lerp, hash, W, H } from './_kit';

const QS: [string, string][] = [['AI 能做到哪一步？', P.paper], ['哪里会出错？', P.warn], ['哪些地方必须人来核？', P.human]];
const TITLE: [string, number][] = [['AI', 0], [' 交流', 1], ['分享', 2]];

export default class Title implements Scene {
  id = 'title';
  start = bar(S.title[0]);
  end = DURATION;

  render(c: C, f: Frame) {
    const t = f.t;
    inkGround(c, t, f.low, 0.03 * (1 - prog(t, at('title') - 0.2, at('title'))));

    // three questions, one per half bar
    if (t < at('title')) {
      const out = prog(t, at('title') - 0.3, at('title') - 0.05);
      QS.forEach(([q, col], i) => {
        const ti = bar(25 + i * 0.5);
        const a = prog(t, ti, ti + 0.25, ease.outCubic) * (1 - out);
        glyphs(c, q, 260, 380 + i * 170, { fam: 'Serif-Bold', size: 96, color: col, align: 'left', track: 2 }, (k) => ({
          a: prog(t, ti + k * 0.025, ti + k * 0.025 + 0.2) * (1 - out), dy: (1 - a) * 20,
        }));
      });
      text(c, '三个真实测试', 260, 250, { fam: 'Sans-Regular', size: 28, color: P.machineOnInk, alpha: prog(t, this.start, this.start + 0.3) * (1 - out), track: 8 });
    }

    // title: token by token, each with a fading probability tag
    const t0 = at('title');
    if (t >= t0) {
      const size = 190, y = 520;
      const full = TITLE.map(([s]) => s).join('');
      const L = layout(c, full, 'Sans-Black', size, 6);
      const x0 = W / 2 - L.width / 2;
      let idx = 0;
      let xEnd = x0;
      TITLE.forEach(([s, k]) => {
        const ti = t0 + k * BEAT;
        const chars = Array.from(s);
        chars.forEach((ch, j) => {
          const gi = idx + j;
          const a = prog(t, ti, ti + 0.18, ease.outCubic);
          if (a > 0) {
            text(c, ch, x0 + L.xs[gi]!, y + (1 - a) * 30, { fam: 'Sans-Black', size, color: P.paper, alpha: a });
            xEnd = Math.max(xEnd, x0 + L.xs[gi]! + L.ws[gi]!);
          }
        });
        const tagA = prog(t, ti + 0.05, ti + 0.2) * (1 - prog(t, ti + 0.9, ti + 1.3));
        const pct = [92, 64, 88][k]!;
        text(c, `${pct}%`, x0 + L.xs[idx + (s.startsWith(' ') ? 1 : 0)]!, y - size * 0.95, { fam: 'Mono', size: 26, color: P.machineOnInk, alpha: tagA });
        idx += chars.length;
      });
      const curOn = t < at('end') + 1.4;
      if (curOn) cursor(c, xEnd + 14, y, size * 0.9, t, P.machineOnInk, prog(t, t0, t0 + 0.2));
      // rule + subtitle
      const s0 = at('sub');
      const ra = prog(t, s0, s0 + 0.5, ease.outExpo);
      c.save(); c.fillStyle = P.machineOnInk; c.globalAlpha = 0.9; c.fillRect(W / 2 - 360 * ra, y + 70, 720 * ra, 3); c.restore();
      caption(c, '从原理到实践', W / 2, y + 170, t, s0 + 0.1, 999, { size: 64, fam: 'Serif-Bold', stagger: 0.05, track: 16 });
      const parts = ['01  动画', '02  图纸', '03  报告'];
      parts.forEach((p, i) => {
        const a = prog(t, s0 + 0.7 + i * BEAT * 0.5, s0 + 0.9 + i * BEAT * 0.5);
        text(c, p, W / 2 + (i - 1) * 300, y + 280, { fam: 'Sans-Regular', size: 32, color: P.ash, align: 'center', alpha: a, track: 4 });
      });
      text(c, '工作常用 AI 的使用观察  ·  2026 年 10 月', W / 2, 1000, { fam: 'Sans-Light', size: 26, color: P.ash, align: 'center', alpha: prog(t, s0 + 1.6, s0 + 2.1), track: 6 });
    }
    const fade = prog(t, DURATION - 1.6, DURATION - 0.2, ease.inOutCubic);
    return { ground: 'ink' as const, grain: 0.07, fade };
  }
}
