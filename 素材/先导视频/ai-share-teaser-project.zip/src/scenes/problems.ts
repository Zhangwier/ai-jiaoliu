// 抽卡 · 幻觉 · 迎合 · 上下文腐烂 — the four failure modes, each one bar, each from the deck.
import type { Scene, Frame } from '../engine/scene';
import type { C } from '../engine/env';
import { S, CUE, at, bar, BEAT, BAR } from '../engine/score';
import { inkGround, tag, caption, typed, text, glyphs, P, rgba, prog, ease, clamp, lerp, hash, noise1, W, H, penCircle } from './_kit';
import { mulberry32 } from '../engine/util';

// a deterministic branching tree: one trunk, splits after "token 103", 80 leaves
const LEAVES = 80;
const tree = (() => {
  const r = mulberry32(7);
  const ys: number[] = [];
  for (let i = 0; i < LEAVES; i++) ys.push(-1 + (2 * (i + 0.5)) / LEAVES + (r() - 0.5) * 0.01);
  return ys;
})();

const FLOOD = [
  '✓ 第 1 处：标注疑似有误', '✓ 第 2 处：单位可能不统一', '✓ 第 3 处：尺寸存疑', '✓ 第 4 处：构件可能缺失',
  '✓ 第 5 处：公式疑为笔误', '✓ 第 6 处：表头不完整', '✓ 第 7 处：重量略偏大',
];

export default class Problems implements Scene {
  id = 'problems';
  start = bar(S.problems[0]);
  end = bar(S.problems[1]);

  render(c: C, f: Frame) {
    const t = f.t;
    inkGround(c, t, f.low, 0.035);
    tag(c, '01', '认识 AI · 四个常见问题', prog(t, this.start, this.start + 0.4) * (1 - prog(t, at('recap') + 1.6, at('recap') + 1.9)));
    const B = (b: number) => bar(b);

    // ---------- 抽卡 (bars 4–6) ----------
    if (t < B(6) + 0.1) {
      const a = 1 - prog(t, B(6) - 0.15, B(6));
      const word = prog(t, at('draw'), at('draw') + 0.25, ease.outBack);
      text(c, '抽卡', 150, 330, { fam: 'Sans-Black', size: 120, color: P.paper, alpha: a * word });
      text(c, '同一句话问两次，答案可能不一样', 150, 400, { fam: 'Sans-Light', size: 32, color: P.ash, alpha: a * prog(t, at('draw') + 0.2, at('draw') + 0.5) });
      // tree: trunk from x=150 to split x, then fan
      const gx0 = 150, gy = 700, sx = 760, ex = 1780, spread = 300;
      const grow = prog(t, at('branch'), B(5.75), ease.inOutCubic);
      c.save();
      c.globalAlpha = a;
      c.lineWidth = 3;
      c.strokeStyle = P.machineOnInk;
      c.beginPath(); c.moveTo(gx0, gy); c.lineTo(lerp(gx0, sx, clamp(grow / 0.35)), gy); c.stroke();
      const fan = clamp((grow - 0.35) / 0.65);
      if (fan > 0) {
        c.lineWidth = 1.4;
        for (let i = 0; i < LEAVES; i++) {
          const ly = tree[i]!;
          const delay = hash(i, 3) * 0.25;
          const u = clamp((fan - delay) / (1 - delay));
          if (u <= 0) continue;
          c.strokeStyle = rgba(P.machineOnInk, 0.25 + 0.5 * hash(i, 9));
          c.beginPath();
          c.moveTo(sx, gy);
          const N = 24;
          for (let k = 1; k <= N * u; k++) {
            const v = k / N;
            const x = lerp(sx, ex, v);
            const y = gy + ly * spread * Math.pow(v, 0.7) + noise1(v * 5 + i, i) * 10 * v;
            c.lineTo(x, y);
          }
          c.stroke();
        }
      }
      c.restore();
      // split marker
      const ma = prog(t, B(4.95), B(5.1)) * a;
      c.save(); c.globalAlpha = ma; c.fillStyle = P.warn; c.beginPath(); c.arc(sx, gy, 8, 0, Math.PI * 2); c.fill(); c.restore();
      text(c, '第 103 个 token 开始分叉', sx - 10, gy - 30, { fam: 'Mono', size: 24, color: P.warn, alpha: ma, align: 'right' });
      text(c, '温度 = 0', gx0, gy - 30, { fam: 'Mono', size: 24, color: P.ash, alpha: prog(t, at('branch'), at('branch') + 0.3) * a });
      // counters
      const ca = prog(t, B(5.25), B(5.4)) * a;
      if (ca > 0) {
        const n1 = Math.round(1000 * prog(t, B(5.25), B(5.6), ease.outCubic));
        const n2 = Math.round(80 * prog(t, B(5.4), B(5.8), ease.outCubic));
        text(c, `${n1}`, 1180, 330, { fam: 'Mono-Med', size: 110, color: P.paper, alpha: ca, align: 'right' });
        text(c, '次', 1200, 330, { fam: 'Sans-Regular', size: 40, color: P.ash, alpha: ca });
        text(c, `${n2}`, 1620, 330, { fam: 'Mono-Med', size: 110, color: P.machineOnInk, alpha: ca, align: 'right' });
        text(c, '种回答', 1640, 330, { fam: 'Sans-Regular', size: 40, color: P.ash, alpha: ca });
        text(c, '→', 1300, 318, { fam: 'Sans-Light', size: 60, color: P.ash, alpha: ca });
      }
    }

    // ---------- 幻觉 (bar 6) ----------
    if (t >= B(6) && t < B(7)) {
      const lt = t - B(6);
      const a = 1 - prog(t, B(7) - 0.12, B(7));
      text(c, '幻觉', 150, 330, { fam: 'Sans-Black', size: 120, color: P.paper, alpha: a * prog(lt, 0, 0.2, ease.outBack) });
      text(c, '它只管“像”，不管“真”', 150, 400, { fam: 'Sans-Light', size: 32, color: P.ash, alpha: a * prog(lt, 0.15, 0.4) });
      // the formula, read wrong: −9/sinβ → 3-9
      const src = '−9/sinβ', dst = '3-9';
      const m = prog(lt, 0.7, 1.1);
      const s = m < 1 ? src : dst;
      glyphs(c, m > 0 && m < 1 ? scramble(src, dst, m, t) : s, 1180, 650, { fam: 'Mono-Med', size: 170, color: m >= 1 ? P.warn : P.paper, align: 'center' }, (i) => ({
        a: a * prog(lt, 0.1 + i * 0.03, 0.3 + i * 0.03), dx: m > 0 && m < 1 ? (hash(i, Math.floor(t * 30)) - 0.5) * 30 : 0,
      }));
      text(c, '原图公式', 1180, 470, { fam: 'Sans-Regular', size: 26, color: P.ash, align: 'center', alpha: a * prog(lt, 0.2, 0.4) * (1 - prog(lt, 0.7, 0.8)) });
      text(c, 'OCR 读成“3-9”，判“疑为 1-9 写错”', 1180, 790, { fam: 'Sans-Regular', size: 32, color: P.warn, align: 'center', alpha: a * prog(lt, 1.15, 1.35) });
    }

    // ---------- 迎合 (bar 7) ----------
    if (t >= B(7) && t < B(8)) {
      const lt = t - B(7);
      const a = 1 - prog(t, B(8) - 0.12, B(8));
      text(c, '迎合', 150, 330, { fam: 'Sans-Black', size: 120, color: P.paper, alpha: a * prog(lt, 0, 0.2, ease.outBack) });
      text(c, '你说有错，它就容易顺着找错', 150, 400, { fam: 'Sans-Light', size: 32, color: P.ash, alpha: a * prog(lt, 0.15, 0.4) });
      // user bubble
      const ba = prog(lt, 0.15, 0.35, ease.outCubic) * a;
      c.save(); c.globalAlpha = ba; c.fillStyle = rgba(P.paper, 0.1); roundRect(c, 900, 220, 860, 96, 18); c.fill(); c.restore();
      text(c, typed('这张图肯定有问题，帮我找出来。', t, B(7) + 0.2, 0.45), 940, 283, { fam: 'Sans-Regular', size: 38, color: P.paper, alpha: ba });
      FLOOD.forEach((s, i) => {
        const fa = prog(lt, 0.75 + i * 0.12, 0.85 + i * 0.12, ease.outCubic) * a;
        text(c, s, 940, 400 + i * 62, { fam: 'Sans-Regular', size: 32, color: P.machineOnInk, alpha: fa });
      });
      text(c, '示意', 1760, 283, { fam: 'Mono', size: 22, color: P.ash, align: 'right', alpha: ba * 0.8 });
      text(c, '找到 7 处问题！', 1760, 400 + 7 * 62 + 10, { fam: 'Sans-Bold', size: 34, color: P.warn, align: 'right', alpha: prog(lt, 1.7, 1.8) * a });
    }

    // ---------- 上下文腐烂 (bar 8) ----------
    if (t >= B(8) && t < B(9)) {
      const lt = t - B(8);
      const a = 1 - prog(t, B(9) - 0.12, B(9));
      text(c, '上下文腐烂', 150, 330, { fam: 'Sans-Black', size: 120, color: P.paper, alpha: a * prog(lt, 0, 0.2, ease.outBack) });
      text(c, '对话越长、资料越多，越容易漏和乱', 150, 400, { fam: 'Sans-Light', size: 32, color: P.ash, alpha: a * prog(lt, 0.15, 0.4) });
      // a long document as a block of lines; the middle rots
      const x0 = 1000, y0 = 160, rows = 64, rh = 12;
      const fill = prog(lt, 0.1, 0.9, ease.outCubic);
      for (let r = 0; r < rows * fill; r++) {
        const u = r / (rows - 1);
        const mid = Math.exp(-Math.pow((u - 0.5) / 0.2, 2));
        const rot = prog(lt, 0.9, 1.6) * mid;
        const w = 300 + hash(r, 4) * 420;
        const jitter = rot * (hash(r, Math.floor(t * 12)) - 0.5) * 40;
        c.save();
        c.globalAlpha = a * (0.75 - rot * 0.62);
        c.fillStyle = r === 6 || r === rows - 5 ? P.machineOnInk : rgba(P.paper, 0.6);
        c.fillRect(x0 + jitter, y0 + r * rh, w * (1 - rot * 0.3), 5);
        c.restore();
      }
      const key = prog(lt, 0.95, 1.1) * a;
      text(c, '关键信息在中间 → 最容易漏', 1830, y0 + 32 * rh + 4, { fam: 'Sans-Bold', size: 28, color: P.warn, align: 'right', alpha: key });
      text(c, '窗口 1M 只说明装得下，不代表都看得清', 150, 800, { fam: 'Sans-Regular', size: 34, color: P.paper, alpha: prog(lt, 1.3, 1.5) * a });
    }

    // ---------- recap (bar 9): 2×2 slam, then the line ----------
    if (t >= B(9)) {
      const lt = t - B(9);
      const words = ['抽卡', '幻觉', '迎合', '上下文腐烂'];
      const roots = ['按概率抽 token', '只挑最像的，不查证', '偏好训练奖励讨好', '注意力被冲淡'];
      const out = prog(t, this.end - 0.15, this.end);
      words.forEach((w, i) => {
        const tx = W / 2 + (i % 2 ? 60 : -60), ty = 360 + Math.floor(i / 2) * 200;
        const ap = prog(lt, i * BEAT * 0.5, i * BEAT * 0.5 + 0.15, ease.outBack) * (1 - out);
        text(c, w, tx, ty, { fam: 'Sans-Black', size: 92, color: P.paper, align: i % 2 ? 'left' : 'right', alpha: ap });
        text(c, roots[i]!, tx, ty + 52, { fam: 'Mono', size: 26, color: P.machineOnInk, align: i % 2 ? 'left' : 'right', alpha: prog(lt, 0.9, 1.1) * (1 - out) });
      });
      caption(c, '四个问题，都能在原理里找到原因', W / 2, 900, t, B(9) + 1.05, this.end - 0.2, { size: 54, fam: 'Serif-Bold', stagger: 0.025 });
    }
    return { ground: 'ink' as const, grain: 0.07 };
  }
  samples(t: number) { return t > bar(4.5) && t < bar(5.8) ? 3 : 1; }
}

function scramble(a: string, b: string, m: number, t: number) {
  const A = Array.from(a), Bc = Array.from(b);
  const n = Math.max(A.length, Bc.length);
  const pool = '0123456789-−/sinβ';
  let s = '';
  for (let i = 0; i < Math.round(lerp(A.length, Bc.length, m)); i++) s += pool[Math.floor(hash(i, Math.floor(t * 30)) * pool.length)];
  return s || b;
}

export function roundRect(c: C, x: number, y: number, w: number, h: number, r: number) {
  c.beginPath();
  c.moveTo(x + r, y); c.lineTo(x + w - r, y); c.quadraticCurveTo(x + w, y, x + w, y + r);
  c.lineTo(x + w, y + h - r); c.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  c.lineTo(x + r, y + h); c.quadraticCurveTo(x, y + h, x, y + h - r);
  c.lineTo(x, y + r); c.quadraticCurveTo(x, y, x + r, y); c.closePath();
}
