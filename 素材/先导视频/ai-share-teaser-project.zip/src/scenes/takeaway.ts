// 04 · 带走三件事: 选配置 · 交代清楚 · 检查结果 — one bar each, then they line up.
import type { Scene, Frame } from '../engine/scene';
import type { C } from '../engine/env';
import { S, at, bar, BEAT } from '../engine/score';
import { inkGround, tag, caption, text, glyphs, penTick, penCircle, P, rgba, prog, ease, clamp, lerp, hash, W, H } from './_kit';

const ITEMS: { n: string; w: string; sub: string[] }[] = [
  { n: '01', w: '选配置', sub: ['模型', '×', '客户端', '×', '设置'] },
  { n: '02', w: '交代清楚', sub: ['目标', '·', '材料', '·', '格式', '·', '怎么算完成'] },
  { n: '03', w: '检查结果', sub: ['回原文', '·', '重算', '·', '打开文件'] },
];

export default class Takeaway implements Scene {
  id = 'takeaway';
  start = bar(S.takeaway[0]);
  end = bar(S.takeaway[1]);

  render(c: C, f: Frame) {
    const t = f.t;
    inkGround(c, t, f.low, 0.04);
    tag(c, '04', '怎么用得稳', prog(t, this.start, this.start + 0.4) * (1 - prog(t, at('tAll') - 0.2, at('tAll'))));

    // intro bar
    if (t < at('t1')) {
      caption(c, '带走三件事', W / 2, H / 2 + 40, t, this.start + 0.15, at('t1') - 0.25, { size: 120, stagger: 0.07 });
    }
    const allP = prog(t, at('tAll'), at('tAll') + 0.6, ease.inOutCubic);
    ITEMS.forEach((it, i) => {
      const ti = bar(21 + i);
      if (t < ti) return;
      const lt = t - ti;
      // solo: huge, centred; then exit until the final row
      const solo = 1 - prog(t, ti + 1.75, ti + 2.0);
      if (t < at('tAll')) {
        if (solo <= 0) return;
        const pop = prog(lt, 0, 0.22, ease.outBack);
        text(c, it.n, W / 2, 330, { fam: 'Mono-Med', size: 40, color: P.machineOnInk, align: 'center', alpha: pop * solo });
        glyphs(c, it.w, W / 2, 560, { fam: 'Sans-Black', size: 210, color: P.paper, align: 'center', track: 10 }, (k) => ({
          a: prog(lt, k * 0.04, k * 0.04 + 0.18) * solo, dy: (1 - prog(lt, k * 0.04, k * 0.04 + 0.25, ease.outExpo)) * 60 - (1 - solo) * 30,
        }));
        // sub-words land on eighths
        c.font = '44px "Sans-Regular"';
        const ws = it.sub.map((s) => c.measureText(s).width + 18);
        let x = W / 2 - ws.reduce((a, b) => a + b, 0) / 2;
        it.sub.forEach((s, k) => {
          const a = prog(lt, 0.45 + k * 0.08, 0.6 + k * 0.08) * solo;
          const sep = s === '×' || s === '·';
          text(c, s, x + 9, 690, { fam: 'Sans-Regular', size: 44, color: sep ? P.ash : P.machineOnInk, alpha: a });
          x += ws[k]!;
        });
        if (i === 2) penTick(c, W / 2 + 520, 470, 110, t, ti + 0.9, 0.3, P.human, 14);
        return;
      }
      // the final row
      const x = lerp(W / 2, 360 + i * 600, allP), y = lerp(560, 560, allP);
      const a = prog(t, at('tAll') + i * 0.12, at('tAll') + i * 0.12 + 0.3);
      text(c, it.n, x, 420, { fam: 'Mono-Med', size: 34, color: P.machineOnInk, align: 'center', alpha: a });
      text(c, it.w, x, y, { fam: 'Sans-Black', size: 110, color: P.paper, align: 'center', alpha: a });
      text(c, it.sub.join(' '), x, y + 80, { fam: 'Sans-Regular', size: 28, color: P.ash, align: 'center', alpha: a });
      if (i === 2) penTick(c, x + 270, y - 50, 60, t, at('tAll') + 0.6, 0.25, P.human, 10);
    });
    if (t > at('tAll')) {
      caption(c, '先讲原理，是为了说明它为什么会出这些错', W / 2, 860, t, at('tAll') + 0.8, this.end - 0.25, { size: 44, fam: 'Serif-Regular', color: P.paper, stagger: 0.02 });
    }
    return { ground: 'ink' as const, grain: 0.07, flash: [at('t1'), at('t2'), at('t3')].reduce((m, x) => m + (t >= x ? 0.18 * Math.max(0, 1 - (t - x) / 0.1) : 0), 0) };
  }
  samples(t: number) { return t > at('tAll') && t < at('tAll') + 0.6 ? 4 : 1; }
}
