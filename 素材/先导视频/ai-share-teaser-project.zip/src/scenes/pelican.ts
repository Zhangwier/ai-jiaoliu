// 02 · 同一句话，十种结果. The deck's pelican blind test: one prompt, ten configurations,
// ten real recordings (frames extracted from the deck's own videos), labels revealed last.
import type { Scene, Frame } from '../engine/scene';
import type { C } from '../engine/env';
import { S, at, bar, BEAT } from '../engine/score';
import { inkGround, tag, caption, typed, text, img, P, rgba, prog, ease, clamp, lerp, hash, W, H } from './_kit';
import { PELICANS, PELICAN_FRAMES, PELICAN_CFG } from '../assets';
import { roundRect } from './problems';

const PROMPT = '“创建一个HTML，内容是SVG绘制一个鹈鹕骑自行车的2D动画，你不需要任何测试”';

export default class Pelican implements Scene {
  id = 'pelican';
  start = bar(S.pelican[0]);
  end = bar(S.pelican[1]);

  render(c: C, f: Frame) {
    const t = f.t;
    inkGround(c, t, f.low, 0.03);
    tag(c, '02', '模型与工具', prog(t, this.start, this.start + 0.4) * (1 - prog(t, this.end - 0.3, this.end)));

    // prompt: big and centred, then it rises to become the header
    const g0 = at('pGrid');
    const rise = prog(t, g0 - 0.25, g0 + 0.2, ease.inOutCubic);
    const py = lerp(H / 2, 175, rise), ps = lerp(46, 28, rise);
    const shown = typed(PROMPT, t, at('pPrompt') + 0.1, 1.5);
    text(c, '提示词', W / 2, py - ps * 1.6, { fam: 'Sans-Regular', size: lerp(26, 20, rise), color: P.machineOnInk, align: 'center', alpha: prog(t, this.start, this.start + 0.3), track: 6 });
    text(c, shown, W / 2, py, { fam: 'Sans-Light', size: ps, color: P.paper, align: 'center' });

    // the grid: 5 × 2 tiles, one every half beat, Ken Burns-free: the recordings ARE the motion
    const cols = 5, tw = 330, th = 248, gap = 26;
    const gw = cols * tw + (cols - 1) * gap;
    const gx = (W - gw) / 2, gy = 250;
    const fps = 16;
    PELICANS.forEach((L, i) => {
      const ti = g0 + i * BEAT * 0.5;
      const pop = prog(t, ti, ti + 0.28, ease.outBack);
      if (pop <= 0) return;
      const col = i % cols, row = Math.floor(i / cols);
      const x = gx + col * (tw + gap), y = gy + row * (th + 110);
      const fi = (Math.floor((t - ti) * fps + i * 7) % PELICAN_FRAMES) + 1;
      c.save();
      c.translate(x + tw / 2, y + th / 2);
      const s = 0.85 + 0.15 * pop;
      c.scale(s, s);
      c.globalAlpha = clamp(pop);
      roundRect(c, -tw / 2, -th / 2, tw, th, 10);
      c.clip();
      img(c, `p${L}${fi}`, -tw / 2, -th / 2, tw, th);
      c.restore();
      // flash frame on arrival
      const fl = Math.max(0, 1 - (t - ti) / 0.12);
      if (fl > 0 && t >= ti) { c.save(); c.globalAlpha = fl * 0.6; c.fillStyle = P.paper; c.fillRect(x, y, tw, th); c.restore(); }
      // letter, then the configuration
      text(c, L, x, y + th + 40, { fam: 'Mono-Med', size: 30, color: P.machineOnInk, alpha: clamp(pop) });
      const la = prog(t, at('pLabels') + i * 0.05, at('pLabels') + i * 0.05 + 0.25);
      const [model, client] = PELICAN_CFG[L]!;
      text(c, model, x + 34, y + th + 39, { fam: 'Sans-Bold', size: 23, color: P.paper, alpha: la });
      text(c, client, x + 34, y + th + 72, { fam: 'Sans-Regular', size: 20, color: P.ash, alpha: la });
      text(c, '?', x + 36, y + th + 40, { fam: 'Mono', size: 28, color: P.ash, alpha: clamp(pop) * (1 - la) });
    });

    // bottom line
    const l0 = at('pLine');
    if (t > l0 - 0.1) {
      const a = prog(t, l0, l0 + 0.3);
      c.save(); c.globalAlpha = a * 0.85; c.fillStyle = P.ink; c.fillRect(0, 960, W, 120); c.restore();
      glyphs3(c, t, l0);
    }
    return { ground: 'ink' as const, grain: 0.06 };
  }
}

/** 实际效果 = 模型 × 外壳 × 设置 — the three factors land on beats. */
function glyphs3(c: C, t: number, l0: number) {
  const parts: [string, string][] = [['同一句话，十种结果：', P.paper], ['模型', P.machineOnInk], [' × ', P.ash], ['客户端', P.machineOnInk], [' × ', P.ash], ['设置', P.machineOnInk]];
  c.font = '44px "Serif-Bold"';
  const widths = parts.map(([s]) => c.measureText(s).width);
  let x = (W - widths.reduce((a, b) => a + b, 0)) / 2;
  parts.forEach(([s, col], i) => {
    const ti = l0 + (i === 0 ? 0 : 0.35 + Math.floor((i - 1) / 2) * BEAT * 0.5);
    const a = prog(t, ti, ti + 0.2, ease.outCubic);
    text(c, s, x, 1035 + (1 - a) * 14, { fam: 'Serif-Bold', size: 44, color: col, alpha: a });
    x += widths[i]!;
  });
}
