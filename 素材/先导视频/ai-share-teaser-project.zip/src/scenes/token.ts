// 01 · 它在一个字一个字地猜. The deck's p.11 performed: each beat the model weighs candidates
// and one drops into the answer. Step 4 it does NOT take the top one — sampling, not looking up.
import type { Scene, Frame } from '../engine/scene';
import type { C } from '../engine/env';
import { S, STEP_BEATS, at, beat, bar } from '../engine/score';
import { inkGround, tag, caption, typed, cursor, text, glyphs, layout, P, rgba, prog, ease, clamp, lerp, W, H } from './_kit';

const PROMPT = '用一句话说说什么是工程量清单';
// [candidates with %], chosen index — exactly as the deck shows them (illustrative numbers)
const STEPS: [string, number][][] = [
  [['工程量', 55], ['它', 20], ['这', 12], ['清单', 8]],
  [['清单', 81], ['表', 9], ['计算', 5], ['是', 3]],
  [['是', 74], ['就是', 15], ['指', 7], ['，', 2]],
  [['列明', 38], ['招标', 31], ['计价', 18], ['一份', 9]],
  [['文件', 62], ['时', 20], ['中', 9], ['人', 4]],
  [['中', 57], ['里', 25], ['的', 10], ['，', 4]],
  [['列明', 66], ['写明', 18], ['规定', 9], ['给出', 4]],
];
const CHOSEN = [0, 0, 0, 1, 0, 0, 0];

export default class Token implements Scene {
  id = 'token';
  start = 0;
  end = bar(S.token[1]);

  render(c: C, f: Frame) {
    const t = f.t;
    inkGround(c, t, f.low, 0.035 * prog(t, 0.3, 1.5));
    tag(c, '01', '认识 AI', prog(t, at('prompt'), at('prompt') + 0.6) * (1 - prog(t, bar(3.6), bar(3.9))));

    // prompt line (the question)
    const pa = 1 - prog(t, bar(3.15), bar(3.4));
    const ptxt = typed(PROMPT, t, at('prompt') + 0.1, 1.2);
    text(c, '提问', 240, 300, { fam: 'Sans-Regular', size: 24, color: P.ash, alpha: pa * prog(t, 0.4, 0.8), track: 4 });
    text(c, ptxt, 320, 302, { fam: 'Sans-Light', size: 40, color: P.paper, alpha: pa });
    if (t < at('steps')) {
      const w = layout(c, ptxt, 'Sans-Light', 40).width;
      cursor(c, 326 + w, 302, 40, t, P.machineOnInk, prog(t, 0.2, 0.5));
    }

    // answer assembly
    const fam = 'Sans-Regular', size = 76, y = 540, x0 = 240;
    const sb = STEP_BEATS.map((b) => beat(b));
    let line: string[] = [];
    for (let k = 0; k < STEPS.length; k++) if (t >= sb[k]! + 0.28) line.push(STEPS[k]![CHOSEN[k]!]![0]);
    const ansA = prog(t, at('steps') - 0.2, at('steps')) * (1 - prog(t, bar(3.15), bar(3.4)));
    text(c, '回答', 240, y - 100, { fam: 'Sans-Regular', size: 24, color: P.ash, alpha: ansA, track: 4 });
    // committed tokens, separated by hairline token boundaries
    c.font = `${size}px "${fam}"`;
    let x = x0;
    const xs: number[] = [];
    line.forEach((tok, k) => {
      const w = c.measureText(tok).width;
      const land = prog(t, sb[k]! + 0.2, sb[k]! + 0.38, ease.outBack);
      const isOdd = CHOSEN[k] !== 0;
      text(c, tok, x, y, { fam, size, color: isOdd ? P.warn : P.paper, alpha: ansA * land });
      c.save();
      c.globalAlpha = ansA * 0.5;
      c.fillStyle = isOdd ? P.warn : P.machineOnInk;
      c.fillRect(x + 2, y + 18, w - 6, 3);
      c.restore();
      xs.push(x);
      x += w + 14;
    });
    const tail = prog(t, beat(12), beat(12) + 0.6);
    if (tail > 0) text(c, '工程数量的表……', x, y, { fam, size, color: P.ash, alpha: ansA * tail });
    if (t >= at('steps') - 0.2 && t < bar(3.55)) cursor(c, x + 4 + (tail > 0 ? 9999 : 0), y, size, t, P.machineOnInk, ansA);

    // candidate stack for the active step
    for (let k = 0; k < STEPS.length; k++) {
      const s0 = sb[k]!, s1 = (sb[k + 1] ?? beat(12)) ;
      if (t < s0 - 0.05 || t > s1) continue;
      const cand = STEPS[k]!;
      const lt = t - s0;
      const out = prog(t, s1 - 0.12, s1);
      const cx = k === 0 ? x0 : x;
      cand.forEach(([tok, pct], j) => {
        const rowY = y + 120 + j * 76;
        const ap = prog(lt, j * 0.03, j * 0.03 + 0.12, ease.outCubic) * (1 - out);
        const chosen = j === CHOSEN[k];
        const fly = chosen ? prog(lt, 0.18, 0.3, ease.inCubic) : 0;
        const dim = !chosen ? prog(lt, 0.2, 0.3) * 0.65 : 0;
        const a = ap * (1 - dim) * (1 - fly);
        const bw = 360 * (pct / 100) * prog(lt, 0.02 + j * 0.03, 0.22 + j * 0.03, ease.outExpo);
        c.save();
        c.globalAlpha = a;
        c.fillStyle = rgba(chosen ? (CHOSEN[k] ? P.warn : P.machineOnInk) : P.ash, chosen ? 0.9 : 0.35);
        c.fillRect(cx + 150, rowY - 26, bw, 30);
        c.restore();
        text(c, tok, cx, rowY + lerp(0, -(rowY - y) , fly), { fam: 'Sans-Regular', size: 42, color: chosen ? P.paper : P.ash, alpha: a + fly * 0 });
        text(c, `${pct}%`, cx + 160 + bw, rowY - 2, { fam: 'Mono', size: 24, color: P.ash, alpha: a });
      });
      if (CHOSEN[k] !== 0) {
        const na = prog(lt, 0.3, 0.5) * (1 - out);
        text(c, '没选最高的：按概率抽中第二名', cx + 640, y + 180, { fam: 'Sans-Bold', size: 30, color: P.warn, alpha: na });
        c.save(); c.globalAlpha = na; c.strokeStyle = P.warn; c.lineWidth = 2;
        c.beginPath(); c.moveTo(cx + 630, y + 170); c.lineTo(cx + 560, y + 178); c.stroke(); c.restore();
      }
    }

    // the line: 它在一个字一个字地猜 (bar 3 → end), the answer shrinks up and away
    const g0 = at('guess');
    if (t > g0 - 0.1) {
      caption(c, '它在一个字一个字地猜', W / 2, H / 2 + 30, t, bar(3.3), this.end + 1, { size: 110, stagger: 0.035 });
      const sub = prog(t, bar(3.55), bar(3.75));
      text(c, '生成本身不保证事实正确', W / 2, H / 2 + 120, { fam: 'Sans-Light', size: 30, color: P.ash, align: 'center', alpha: sub, track: 6 });
    }
    return { ground: 'ink' as const, grain: 0.07 };
  }
  samples(t: number) {
    const sb = STEP_BEATS.map((b) => beat(b));
    return sb.some((s) => t > s + 0.15 && t < s + 0.35) ? 5 : 1;
  }
}
