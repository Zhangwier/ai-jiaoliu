// The edit: six plates on downbeats, all reading one clock (src/engine/score.ts).
import type { Scene } from './engine/scene';
import Token from './scenes/token';
import Problems from './scenes/problems';
import Pelican from './scenes/pelican';
import Cases from './scenes/cases';
import Takeaway from './scenes/takeaway';
import Title from './scenes/title';

export function makeTimeline(): Scene[] {
  return [new Token(), new Problems(), new Pelican(), new Cases(), new Takeaway(), new Title()];
}
