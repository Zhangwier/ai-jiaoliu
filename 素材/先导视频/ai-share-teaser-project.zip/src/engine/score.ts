// Single clock for picture and sound. 120 BPM: one beat = 0.5 s, one bar = 2 s.
export const BPM = 120;
export const BEAT = 60 / BPM;
export const BAR = BEAT * 4;
export const T0 = 0.5;
export const BARS = 30;
export const DURATION = 63;

export const bar = (b: number) => T0 + b * BAR;
export const beat = (n: number) => T0 + n * BEAT;
export const beatAt = (t: number) => (t - T0) / BEAT;
export const barAt = (t: number) => (t - T0) / BAR;

/** Sections in bars. */
export const S = {
  token: [0, 4],      // 它在一个字一个字地猜
  problems: [4, 10],  // 抽卡 · 幻觉 · 迎合 · 上下文腐烂
  pelican: [10, 14],  // 同一句话，十种结果
  cases: [14, 20],    // 图纸 · 修编报告
  takeaway: [20, 25], // 选配置 · 交代清楚 · 检查结果
  title: [25, 31.25], // 片名
} as const;

/** Token-generation steps (beats from bar 0), from deck p.11. */
export const STEP_BEATS = [4, 5, 6, 7, 9, 10, 11];

export const CUE = {
  prompt: 0, steps: 1, guess: 3,
  draw: 4, branch: 4.5, hallu: 6, syco: 7, rot: 8, recap: 9,
  pPrompt: 10, pGrid: 11, pLabels: 12.5, pLine: 13,
  dIntro: 14, dK1: 15, dK2: 15.75, dScore: 16, rIntro: 17, rTypo: 18, rTpl: 18.75, rLine: 19,
  tIntro: 20, t1: 21, t2: 22, t3: 23, tAll: 24,
  q1: 25, q2: 25.5, q3: 26, title: 27, sub: 28, end: 30,
} as const;
export const at = (c: keyof typeof CUE) => bar(CUE[c]);
