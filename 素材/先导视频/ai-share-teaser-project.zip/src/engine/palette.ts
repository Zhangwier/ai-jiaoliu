// Palette taken from the deck (navy 12203A, teal 0F766E, mint 9CCFC8, pale E6ECF5).
//  machine (mint / teal): what the model produces — tokens, drafts, results
//  warn (amber): where the model goes wrong — hallucination, false errors, typos
//  human (coral): ONLY the person checking — the circle, the strike, the tick
export const P = {
  paper: '#E9EEF5',
  paper2: '#DCE3EE',
  ink: '#0B1528',
  ink2: '#12203A',
  graphite: '#4A5A78',
  ash: '#8D9BB3',
  rule: '#C9D3E3',
  human: '#FF5A3C',
  warn: '#F2B33D',
  machineOnPaper: '#0F766E',
  machineOnInk: '#7FE0CF',
};
export function rgba(hex: string, a = 1) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}
export function mix(h1: string, h2: string, t: number, a = 1) {
  const p = (h: string) => { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
  const x = p(h1), y = p(h2);
  const c = x.map((v, i) => Math.round(v + (y[i]! - v) * t));
  return `rgba(${c[0]},${c[1]},${c[2]},${a})`;
}
