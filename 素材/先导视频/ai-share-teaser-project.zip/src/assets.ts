// Every bitmap the teaser uses, all taken from the deck (AI交流分享-成品21.pptx).
export const PELICANS = 'ABCDEFGHIJ'.split('');
export const PELICAN_FRAMES = 64; // 4 s at 16 fps, extracted by scripts/assets.sh
export const PELICAN_CFG: Record<string, [string, string]> = {
  A: ['GLM 5.3 Flash', 'Trae'], B: ['Seed 2.1 Turbo', 'Trae'], C: ['DeepSeek V4.1 Flash 1M', 'WorkBuddy'],
  D: ['Opus 5.5', 'Hark'], E: ['HY4 Preview 1M high', 'WorkBuddy'], F: ['Step 5 Preview', 'WorkBuddy'],
  G: ['GPT 6.1 Sol high', 'Codex'], H: ['Auto fast', 'WorkBuddy'], I: ['Qwen 3.8 Flash', 'Qoder'], J: ['MiniMax M3', 'WorkBuddy'],
};
export function assetList(): Record<string, string> {
  const m: Record<string, string> = { sheet: 'assets/sheet.png', k1: 'assets/k1.png', k2: 'assets/k2.png', report: 'assets/report.png' };
  for (const L of PELICANS) for (let i = 1; i <= PELICAN_FRAMES; i++) m[`p${L}${i}`] = `assets/pelican/${L}/${String(i).padStart(2, '0')}.jpg`;
  return m;
}
