# AI 交流分享 · 先导片 (teaser)

63 s, 16:9, 1920×1080 @ 60 fps (4K via `--scale 2`). Same deterministic engine as ../film
(《超出一人之力》): one clock (`src/engine/score.ts`, 120 BPM, bar = 2 s), Canvas2D scenes,
original synthesized score, motion blur, grain. All facts and images come from the deck
`AI交流分享-成品21.pptx` (pelican recordings, drawing details, report header).

Structure (bars): 0–4 它在一个字一个字地猜 · 4–10 抽卡/幻觉/迎合/上下文腐烂 · 10–14 鹈鹕盲测 十种结果 ·
14–20 案例：图纸（K1/K2、3/10、30 条假错误）与修编报告（复算、笔误、旧模板） · 20–25 带走三件事 · 25–31 三个问题 + 片名.
Colour semantics: mint = model output, amber = model error, coral = the person checking.

```
npm install            # or reuse ../film/node_modules
sh fonts/fetch-fonts.sh
sh scripts/assets.sh /path/to/deck/ppt/media   # pelican frames + images → assets/
npx tsx scripts/synth.ts
npx tsx scripts/render.ts sheet --from 0 --to 63 --n 24
npx tsx scripts/render.ts video --out out/teaser.mp4 [--scale 2]
```
